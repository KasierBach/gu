import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Shop } from './components/Shop';
import { ProductModal } from './components/ProductModal';
import { Cart } from './components/Cart';
import { Exchange } from './components/Exchange';
import { Deals } from './components/Deals';
import { Contact } from './components/Contact';
import { Product, CartItem, ViewState } from './types';
import { PRODUCTS } from './constants';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('HOME');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Cart Logic
  const addToCart = (product: Product, quantity = 1) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id 
            ? { ...item, quantity: item.quantity + quantity } 
            : item
        );
      }
      return [...prev, { ...product, quantity }];
    });
    // Optional: Open cart briefly or show toast (not implemented for simplicity)
  };

  const updateQuantity = (id: string, delta: number) => {
    setCartItems(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, quantity: Math.max(1, item.quantity + delta) };
      }
      return item;
    }));
  };

  const removeItem = (id: string) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  // Navigation Logic
  const renderView = () => {
    switch (currentView) {
      case 'HOME':
        return (
          <>
            <Hero onShopNow={() => setCurrentView('SHOP')} />
            <div className="py-12 px-4 max-w-7xl mx-auto">
              <h2 className="text-3xl font-display font-bold text-white mb-8 border-l-4 border-gundam-red pl-4">Featured Models</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {PRODUCTS.slice(0, 3).map(p => (
                   <div key={p.id} className="transform hover:-translate-y-2 transition-transform duration-300">
                      {/* Simple reuse of Shop component style logic would be better, but we render ProductCard manually here */}
                      <div className="bg-slate-800 border border-slate-700 overflow-hidden group">
                         <div className="relative h-64 overflow-hidden">
                            <img src={p.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt={p.name} />
                         </div>
                         <div className="p-4">
                            <h3 className="text-white font-bold text-lg">{p.name}</h3>
                            <button 
                                onClick={() => {
                                    setSelectedProduct(p);
                                }}
                                className="mt-2 text-gundam-blue text-sm font-bold uppercase hover:text-white"
                            >
                                View Specs &rarr;
                            </button>
                         </div>
                      </div>
                   </div>
                ))}
              </div>
            </div>
            {/* Quick Deal Teaser */}
            <div className="bg-gundam-blue py-12 text-center text-white">
               <h2 className="text-4xl font-display font-bold mb-4">WEEKLY SPECIALS</h2>
               <button onClick={() => setCurrentView('DEALS')} className="bg-white text-gundam-blue px-8 py-3 font-bold uppercase rounded-sm hover:bg-slate-200">
                  Check Discounts
               </button>
            </div>
          </>
        );
      case 'SHOP':
        return <Shop onAddToCart={addToCart} onViewDetails={setSelectedProduct} />;
      case 'EXCHANGE':
        return <Exchange />;
      case 'DEALS':
        return <Deals onAddToCart={addToCart} onViewDetails={setSelectedProduct} />;
      case 'CONTACT':
        return <Contact />;
      default:
        return <Shop onAddToCart={addToCart} onViewDetails={setSelectedProduct} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans selection:bg-gundam-blue selection:text-white">
      <Navbar 
        currentView={currentView} 
        onNavigate={setCurrentView} 
        cartCount={cartCount}
        onOpenCart={() => setIsCartOpen(true)}
      />

      <main className="flex-grow">
        {renderView()}
      </main>

      <footer className="bg-slate-950 border-t border-slate-800 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <span className="font-display font-bold text-2xl tracking-wider text-white">
                GUNDAM<span className="text-gundam-blue">UNIVERSE</span>
              </span>
              <p className="mt-4 text-slate-500 max-w-xs">
                The premier destination for Gunpla builders. High grades, Master grades, and community exchanges all in one place.
              </p>
            </div>
            <div>
              <h4 className="text-white font-bold uppercase mb-4">Links</h4>
              <ul className="space-y-2 text-slate-500 text-sm">
                <li className="hover:text-gundam-blue cursor-pointer" onClick={() => setCurrentView('SHOP')}>Shop</li>
                <li className="hover:text-gundam-blue cursor-pointer" onClick={() => setCurrentView('EXCHANGE')}>Exchange</li>
                <li className="hover:text-gundam-blue cursor-pointer" onClick={() => setCurrentView('CONTACT')}>Support</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold uppercase mb-4">Newsletter</h4>
              <div className="flex">
                <input type="text" placeholder="Email" className="bg-slate-900 border border-slate-700 px-3 py-2 text-sm w-full focus:border-gundam-blue outline-none" />
                <button className="bg-gundam-red px-4 text-white font-bold text-sm hover:bg-red-700">→</button>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-slate-800 text-center text-slate-600 text-sm">
            © {new Date().getFullYear()} Gundam Universe. This is a demo project. Not affiliated with Bandai.
          </div>
        </div>
      </footer>

      {/* Overlays */}
      <ProductModal 
        product={selectedProduct} 
        isOpen={!!selectedProduct} 
        onClose={() => setSelectedProduct(null)} 
        onAddToCart={addToCart}
      />

      <Cart 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
        items={cartItems} 
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeItem}
      />
    </div>
  );
};

export default App;