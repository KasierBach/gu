import React, { useState } from 'react';
import { Product } from '../types';
import { X, ShoppingBag, Heart, Shield, Scale, Hammer } from 'lucide-react';

interface ProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({ product, isOpen, onClose, onAddToCart }) => {
  const [quantity, setQuantity] = useState(1);

  if (!isOpen || !product) return null;

  const handleAddToCart = () => {
    onAddToCart(product, quantity);
    onClose();
  };

  const currentPrice = product.salePrice || product.price;

  return (
    <div className="fixed inset-0 z-[60] overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
      <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 bg-slate-900/90 transition-opacity" aria-hidden="true" onClick={onClose}></div>

        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        <div className="inline-block align-bottom bg-slate-900 border border-slate-700 text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl sm:w-full">
          
          <div className="absolute top-0 right-0 pt-4 pr-4 z-10">
            <button 
              onClick={onClose}
              className="bg-slate-800 rounded-full p-2 text-slate-400 hover:text-white hover:bg-slate-700 focus:outline-none"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2">
            {/* Image Section */}
            <div className="relative h-96 md:h-full bg-slate-800">
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-slate-900 to-transparent h-24"></div>
            </div>

            {/* Info Section */}
            <div className="p-8">
              <div className="mb-4">
                <div className="flex items-center space-x-2 mb-2">
                   <span className="px-2 py-1 bg-gundam-blue text-white text-xs font-bold uppercase rounded">{product.grade}</span>
                   <span className="px-2 py-1 border border-slate-600 text-slate-300 text-xs font-bold uppercase rounded">{product.series}</span>
                </div>
                <h3 className="text-3xl font-display font-bold text-white mb-2">{product.name}</h3>
                <p className="text-2xl text-gundam-yellow font-bold">${currentPrice.toFixed(2)}</p>
              </div>

              <p className="text-slate-300 mb-6 leading-relaxed border-l-2 border-slate-600 pl-4">
                {product.description}
              </p>

              {/* Specs Grid */}
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-slate-800 p-3 rounded border border-slate-700 flex items-center">
                    <Scale className="h-5 w-5 text-gundam-blue mr-3" />
                    <div>
                        <p className="text-xs text-slate-500 uppercase">Scale</p>
                        <p className="text-sm font-bold text-white">{product.scale}</p>
                    </div>
                </div>
                <div className="bg-slate-800 p-3 rounded border border-slate-700 flex items-center">
                    <Hammer className="h-5 w-5 text-gundam-red mr-3" />
                    <div>
                        <p className="text-xs text-slate-500 uppercase">Difficulty</p>
                        <p className="text-sm font-bold text-white">{product.difficulty}</p>
                    </div>
                </div>
              </div>

              {/* Controls */}
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <div className="flex items-center bg-slate-800 border border-slate-600 rounded w-max">
                  <button 
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-700 border-r border-slate-600"
                  >
                    -
                  </button>
                  <span className="px-4 py-2 text-white font-bold w-12 text-center">{quantity}</span>
                  <button 
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-700 border-l border-slate-600"
                  >
                    +
                  </button>
                </div>
                
                <button 
                  onClick={handleAddToCart}
                  className="flex-1 bg-gundam-blue hover:bg-blue-700 text-white font-bold py-3 px-6 uppercase tracking-wider flex items-center justify-center transition-colors"
                >
                  <ShoppingBag className="mr-2 h-5 w-5" />
                  Add to Cart
                </button>

                <button 
                  onClick={() => alert("Added to Wishlist!")}
                  className="p-3 border border-slate-600 text-slate-400 hover:text-gundam-red hover:border-gundam-red transition-colors"
                >
                  <Heart className="h-6 w-6" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};