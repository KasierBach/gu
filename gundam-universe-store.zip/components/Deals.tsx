import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { PRODUCTS } from '../constants';
import { ProductCard } from './ProductCard';
import { Timer, Zap } from 'lucide-react';

interface DealsProps {
  onAddToCart: (product: Product) => void;
  onViewDetails: (product: Product) => void;
}

export const Deals: React.FC<DealsProps> = ({ onAddToCart, onViewDetails }) => {
  const [timeLeft, setTimeLeft] = useState({
    hours: 12,
    minutes: 45,
    seconds: 0
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return prev; // Timer done
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const saleProducts = PRODUCTS.filter(p => p.salePrice);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-gradient-to-r from-gundam-red to-red-800 rounded-lg p-8 mb-12 text-center text-white relative overflow-hidden shadow-2xl">
         {/* Background pattern */}
         <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#fff_1px,transparent_1px)] bg-[size:16px_16px]"></div>
         
         <div className="relative z-10">
            <h2 className="text-4xl md:text-6xl font-display font-black uppercase mb-4 tracking-tighter italic">Flash Sale</h2>
            <div className="flex justify-center items-center space-x-6 text-2xl md:text-4xl font-mono font-bold bg-black/30 inline-block px-8 py-4 rounded border border-white/20 backdrop-blur">
                <div className="flex flex-col items-center">
                    <span>{String(timeLeft.hours).padStart(2, '0')}</span>
                    <span className="text-xs font-sans font-normal opacity-70">HRS</span>
                </div>
                <span>:</span>
                <div className="flex flex-col items-center">
                    <span>{String(timeLeft.minutes).padStart(2, '0')}</span>
                    <span className="text-xs font-sans font-normal opacity-70">MIN</span>
                </div>
                <span>:</span>
                <div className="flex flex-col items-center text-gundam-yellow">
                    <span>{String(timeLeft.seconds).padStart(2, '0')}</span>
                    <span className="text-xs font-sans font-normal opacity-70">SEC</span>
                </div>
            </div>
         </div>
      </div>

      <div className="mb-8 flex items-center">
         <Zap className="text-gundam-yellow mr-2 h-6 w-6" />
         <h3 className="text-2xl font-bold text-white uppercase">Limited Time Offers</h3>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {saleProducts.map(product => (
          <ProductCard 
            key={product.id} 
            product={product} 
            onAddToCart={onAddToCart}
            onViewDetails={onViewDetails}
          />
        ))}
        {/* Mocking more items to fill the grid if needed */}
        {saleProducts.length < 3 && PRODUCTS.slice(0, 3 - saleProducts.length).map(product => (
             <ProductCard 
                key={`mock-${product.id}`} 
                product={{...product, salePrice: product.price * 0.9, id: `sale-${product.id}`}} // Mock sale
                onAddToCart={onAddToCart}
                onViewDetails={onViewDetails}
              />
        ))}
      </div>
    </div>
  );
};