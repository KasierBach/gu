import React from 'react';
import { ViewState } from '../types';
import { ArrowRight, ChevronRight } from 'lucide-react';

interface HeroProps {
  onShopNow: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onShopNow }) => {
  return (
    <div className="relative overflow-hidden bg-slate-900 h-[600px] flex items-center">
      {/* Background Image / Gradient */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/80 to-transparent z-10"></div>
        <img 
          src="https://picsum.photos/seed/space/1920/1080" 
          alt="Space Background" 
          className="w-full h-full object-cover opacity-50"
        />
        {/* Animated Grid Overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(0,87,183,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(0,87,183,0.1)_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_60%_at_50%_50%,#000_70%,transparent_100%)]"></div>
      </div>

      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="lg:w-1/2">
          <div className="inline-flex items-center px-3 py-1 rounded-full border border-gundam-blue/50 bg-gundam-blue/10 text-gundam-blue mb-6 backdrop-blur-sm">
            <span className="flex h-2 w-2 rounded-full bg-gundam-blue mr-2 animate-pulse"></span>
            <span className="text-sm font-semibold tracking-wide uppercase">New Arrivals In Stock</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-display font-black text-white leading-tight mb-6 uppercase">
            Build Your Own <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-gundam-blue to-cyan-400">
              Gundam Universe
            </span>
          </h1>
          
          <p className="text-xl text-slate-300 mb-8 max-w-lg font-light border-l-4 border-gundam-yellow pl-4">
            Experience the ultimate collection of Gunpla. From High Grade to Perfect Grade, ignite your passion for mecha engineering.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={onShopNow}
              className="group relative px-8 py-4 bg-gundam-red text-white font-bold uppercase tracking-wider overflow-hidden clip-path-slant"
            >
              <div className="absolute inset-0 w-full h-full bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
              <span className="relative flex items-center">
                Shop Now <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </span>
            </button>
            
            <button className="px-8 py-4 border border-slate-600 text-slate-300 hover:text-white hover:border-white font-bold uppercase tracking-wider transition-all">
              View Collection
            </button>
          </div>
        </div>
      </div>
      
      {/* Decorative Elements */}
      <div className="absolute bottom-0 right-0 w-1/3 h-1/3 bg-gradient-to-t from-gundam-blue/20 to-transparent blur-3xl"></div>
    </div>
  );
};