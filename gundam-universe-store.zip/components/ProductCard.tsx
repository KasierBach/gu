import React from 'react';
import { Product } from '../types';
import { ShoppingBag, Plus } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onViewDetails: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onViewDetails }) => {
  const discountPercent = product.salePrice 
    ? Math.round(((product.price - product.salePrice) / product.price) * 100) 
    : 0;

  return (
    <div className="group relative bg-slate-800 border border-slate-700 hover:border-gundam-blue transition-all duration-300 overflow-hidden flex flex-col h-full">
      {/* Badges */}
      <div className="absolute top-0 left-0 z-10 flex flex-col gap-1 p-2">
        {product.salePrice && (
          <span className="bg-gundam-red text-white text-xs font-bold px-2 py-1 uppercase tracking-wider shadow-md">
            -{discountPercent}%
          </span>
        )}
        {product.isNew && (
          <span className="bg-gundam-yellow text-slate-900 text-xs font-bold px-2 py-1 uppercase tracking-wider shadow-md">
            New
          </span>
        )}
      </div>

      {/* Image Container */}
      <div 
        className="relative w-full aspect-square overflow-hidden cursor-pointer"
        onClick={() => onViewDetails(product)}
      >
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <button className="px-6 py-2 border-2 border-white text-white font-bold uppercase tracking-widest hover:bg-white hover:text-black transition-colors">
            View Details
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <span className="text-gundam-blue text-xs font-bold uppercase tracking-widest border border-gundam-blue/30 px-1 rounded">
            {product.grade}
          </span>
          <span className="text-slate-400 text-xs uppercase">{product.series}</span>
        </div>
        
        <h3 
          className="text-lg font-display font-bold text-white mb-2 leading-tight cursor-pointer hover:text-gundam-blue transition-colors"
          onClick={() => onViewDetails(product)}
        >
          {product.name}
        </h3>

        <div className="mt-auto flex items-center justify-between">
          <div className="flex flex-col">
            {product.salePrice ? (
              <>
                <span className="text-slate-500 text-sm line-through">${product.price.toFixed(2)}</span>
                <span className="text-gundam-red text-xl font-bold">${product.salePrice.toFixed(2)}</span>
              </>
            ) : (
              <span className="text-white text-xl font-bold">${product.price.toFixed(2)}</span>
            )}
          </div>

          <button 
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart(product);
            }}
            className="p-2 bg-slate-700 hover:bg-gundam-blue text-white rounded-sm transition-colors group-active:scale-95"
            aria-label="Add to cart"
          >
            <Plus className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
};