import React from 'react';

export const Contact: React.FC = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Transmission sent! We will respond via secure channel shortly.");
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-16">
      <div className="bg-slate-800 border border-slate-700 p-8 md:p-12 relative overflow-hidden">
        {/* Decorative corner */}
        <div className="absolute top-0 right-0 w-24 h-24 bg-gundam-blue/10 transform rotate-45 translate-x-12 -translate-y-12"></div>
        
        <div className="text-center mb-10">
          <h2 className="text-3xl font-display font-bold text-white mb-2">Secure Channel</h2>
          <p className="text-slate-400">Questions about orders, customs, or part replacements?</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Codename / Name</label>
              <input 
                required 
                type="text" 
                className="w-full bg-slate-900 border border-slate-600 p-3 text-white focus:border-gundam-blue outline-none"
                placeholder="Enter your name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Frequency / Email</label>
              <input 
                required 
                type="email" 
                className="w-full bg-slate-900 border border-slate-600 p-3 text-white focus:border-gundam-blue outline-none"
                placeholder="pilot@example.com"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-slate-400 mb-1">Transmission Data</label>
            <textarea 
              required 
              rows={5} 
              className="w-full bg-slate-900 border border-slate-600 p-3 text-white focus:border-gundam-blue outline-none"
              placeholder="Type your message here..."
            ></textarea>
          </div>

          <button 
            type="submit" 
            className="w-full bg-slate-100 hover:bg-white text-slate-900 font-bold py-4 uppercase tracking-widest transition-colors clip-path-slant"
          >
            Send Transmission
          </button>
        </form>
      </div>
    </div>
  );
};