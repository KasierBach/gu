import React, { useState, useMemo } from 'react';
import { Product, Grade, Series } from '../types';
import { PRODUCTS } from '../constants';
import { ProductCard } from './ProductCard';
import { Search, Filter, SlidersHorizontal } from 'lucide-react';

interface ShopProps {
  onAddToCart: (product: Product) => void;
  onViewDetails: (product: Product) => void;
}

export const Shop: React.FC<ShopProps> = ({ onAddToCart, onViewDetails }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGrades, setSelectedGrades] = useState<Grade[]>([]);
  const [selectedSeries, setSelectedSeries] = useState<Series[]>([]);
  const [priceSort, setPriceSort] = useState<'asc' | 'desc' | null>(null);

  const toggleGrade = (grade: Grade) => {
    setSelectedGrades(prev => 
      prev.includes(grade) ? prev.filter(g => g !== grade) : [...prev, grade]
    );
  };

  const filteredProducts = useMemo(() => {
    let result = PRODUCTS.filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesGrade = selectedGrades.length === 0 || selectedGrades.includes(p.grade);
      // For simplicity, strict series filtering not implemented in UI but logic is here
      return matchesSearch && matchesGrade;
    });

    if (priceSort) {
      result.sort((a, b) => {
        const priceA = a.salePrice || a.price;
        const priceB = b.salePrice || b.price;
        return priceSort === 'asc' ? priceA - priceB : priceB - priceA;
      });
    }

    return result;
  }, [searchTerm, selectedGrades, priceSort]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row justify-between items-end mb-8 border-b border-slate-700 pb-6 gap-6">
        <div>
          <h2 className="text-3xl font-display font-bold text-white mb-2">Mobile Suit Hangar</h2>
          <p className="text-slate-400">Select your unit and prepare for deployment.</p>
        </div>
        
        {/* Search & Sort Controls */}
        <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
          <div className="relative">
            <input
              type="text"
              placeholder="Search Mobile Suits..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full sm:w-64 bg-slate-800 border border-slate-600 text-white px-4 py-2 pl-10 focus:outline-none focus:border-gundam-blue transition-colors rounded-sm"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          </div>
          
          <select 
            onChange={(e) => setPriceSort(e.target.value as any)}
            className="bg-slate-800 border border-slate-600 text-white px-4 py-2 focus:outline-none focus:border-gundam-blue rounded-sm"
          >
            <option value="">Sort by Price</option>
            <option value="asc">Low to High</option>
            <option value="desc">High to Low</option>
          </select>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Sidebar Filters */}
        <div className="w-full lg:w-64 flex-shrink-0 space-y-8">
          <div>
            <h3 className="text-lg font-bold text-white mb-4 flex items-center">
              <Filter className="h-4 w-4 mr-2 text-gundam-blue" />
              Grade
            </h3>
            <div className="space-y-2">
              {Object.values(Grade).map((grade) => (
                <label key={grade} className="flex items-center space-x-3 cursor-pointer group">
                  <div className={`w-5 h-5 flex items-center justify-center border transition-colors ${selectedGrades.includes(grade) ? 'bg-gundam-blue border-gundam-blue' : 'border-slate-600 group-hover:border-slate-400'}`}>
                    {selectedGrades.includes(grade) && <div className="w-2 h-2 bg-white rounded-full" />}
                  </div>
                  <input 
                    type="checkbox" 
                    className="hidden"
                    checked={selectedGrades.includes(grade)}
                    onChange={() => toggleGrade(grade)}
                  />
                  <span className={`text-sm ${selectedGrades.includes(grade) ? 'text-white' : 'text-slate-400 group-hover:text-slate-300'}`}>{grade}</span>
                </label>
              ))}
            </div>
          </div>
          
          {/* Decorative Panel */}
          <div className="p-4 border border-slate-700 bg-slate-800/50">
            <h4 className="text-xs font-bold text-slate-500 uppercase mb-2">System Status</h4>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-gundam-blue">GN Drive</span>
              <div className="w-16 h-1 bg-slate-700 overflow-hidden">
                <div className="h-full bg-gundam-blue animate-pulse w-3/4"></div>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-gundam-red">Output</span>
              <div className="w-16 h-1 bg-slate-700 overflow-hidden">
                <div className="h-full bg-gundam-red w-full"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Product Grid */}
        <div className="flex-grow">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map(product => (
              <ProductCard 
                key={product.id} 
                product={product} 
                onAddToCart={onAddToCart}
                onViewDetails={onViewDetails}
              />
            ))}
          </div>
          {filteredProducts.length === 0 && (
            <div className="text-center py-20 border border-dashed border-slate-700 rounded-lg">
              <p className="text-slate-400 text-lg">No units found matching your criteria.</p>
              <button 
                onClick={() => {setSelectedGrades([]); setSearchTerm('');}}
                className="mt-4 text-gundam-blue hover:underline"
              >
                Clear Filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};