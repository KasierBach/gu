import React, { useState, useEffect } from 'react';
import { ExchangePost } from '../types';
import { INITIAL_EXCHANGE_POSTS } from '../constants';
import { Send, User, RefreshCw } from 'lucide-react';

export const Exchange: React.FC = () => {
  const [posts, setPosts] = useState<ExchangePost[]>(() => {
    const saved = localStorage.getItem('exchange_posts');
    return saved ? JSON.parse(saved) : INITIAL_EXCHANGE_POSTS;
  });

  const [formData, setFormData] = useState({
    author: '',
    have: '',
    want: '',
    condition: 'New (In Box)' as ExchangePost['condition']
  });

  useEffect(() => {
    localStorage.setItem('exchange_posts', JSON.stringify(posts));
  }, [posts]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newPost: ExchangePost = {
      id: Date.now().toString(),
      author: formData.author,
      have: formData.have,
      want: formData.want,
      condition: formData.condition,
      date: new Date().toLocaleDateString()
    };
    setPosts([newPost, ...posts]);
    setFormData({ author: '', have: '', want: '', condition: 'New (In Box)' });
    alert("Exchange request posted!");
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-display font-bold text-white mb-4">Exchange Center</h2>
        <p className="text-slate-400 max-w-2xl mx-auto">
          Trade your Gunpla with other builders. Connect, negotiate, and expand your collection without spending credits.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Post Form */}
        <div className="bg-slate-800/50 p-6 border border-slate-700 rounded-lg lg:col-span-1 h-fit sticky top-24">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center">
            <Send className="mr-2 text-gundam-blue" />
            Create Listing
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Pilot Name</label>
              <input
                required
                type="text"
                className="w-full bg-slate-900 border border-slate-600 rounded p-2 text-white focus:border-gundam-blue outline-none"
                value={formData.author}
                onChange={e => setFormData({...formData, author: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Have (Offering)</label>
              <input
                required
                type="text"
                className="w-full bg-slate-900 border border-slate-600 rounded p-2 text-white focus:border-gundam-blue outline-none"
                value={formData.have}
                onChange={e => setFormData({...formData, have: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Want (Looking For)</label>
              <input
                required
                type="text"
                className="w-full bg-slate-900 border border-slate-600 rounded p-2 text-white focus:border-gundam-blue outline-none"
                value={formData.want}
                onChange={e => setFormData({...formData, want: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Condition</label>
              <select
                className="w-full bg-slate-900 border border-slate-600 rounded p-2 text-white focus:border-gundam-blue outline-none"
                value={formData.condition}
                onChange={e => setFormData({...formData, condition: e.target.value as any})}
              >
                <option>New (In Box)</option>
                <option>Built (With Box)</option>
                <option>Built (No Box)</option>
                <option>Custom Painted</option>
              </select>
            </div>
            <button
              type="submit"
              className="w-full bg-gundam-blue hover:bg-blue-700 text-white font-bold py-3 rounded uppercase tracking-wider transition-colors"
            >
              Post Request
            </button>
          </form>
        </div>

        {/* Listings Feed */}
        <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-white">Recent Listings</h3>
                <span className="text-slate-500 text-sm">{posts.length} active posts</span>
            </div>
            
            {posts.map(post => (
                <div key={post.id} className="bg-slate-800 border border-slate-700 p-6 rounded-lg hover:border-gundam-blue/50 transition-colors group">
                    <div className="flex flex-col sm:flex-row justify-between sm:items-start mb-4">
                        <div className="flex items-center space-x-3 mb-2 sm:mb-0">
                            <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center">
                                <User className="text-slate-400" />
                            </div>
                            <div>
                                <p className="text-white font-bold">{post.author}</p>
                                <p className="text-slate-500 text-xs">Posted on {post.date}</p>
                            </div>
                        </div>
                        <span className={`px-3 py-1 rounded text-xs font-bold uppercase ${
                            post.condition.includes('New') ? 'bg-gundam-blue/20 text-gundam-blue' : 'bg-orange-500/20 text-orange-400'
                        }`}>
                            {post.condition}
                        </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-900/50 p-4 rounded border border-slate-700/50">
                        <div>
                            <p className="text-xs text-slate-500 uppercase mb-1">Offering</p>
                            <p className="text-lg font-display text-gundam-blue font-bold">{post.have}</p>
                        </div>
                        <div className="flex items-center">
                             <RefreshCw className="h-5 w-5 text-slate-600 mx-auto hidden md:block" />
                        </div>
                         <div>
                            <p className="text-xs text-slate-500 uppercase mb-1">Looking For</p>
                            <p className="text-lg font-display text-gundam-red font-bold">{post.want}</p>
                        </div>
                    </div>

                    <div className="mt-4 flex justify-end">
                        <button 
                            onClick={() => alert(`Contacting ${post.author}...`)}
                            className="text-sm font-medium text-slate-400 hover:text-white transition-colors"
                        >
                            Contact Pilot &rarr;
                        </button>
                    </div>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};