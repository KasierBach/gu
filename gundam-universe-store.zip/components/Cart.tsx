import React, { useState } from 'react';
import { CartItem } from '../types';
import { X, Trash2, ShoppingBag, Tag } from 'lucide-react';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
}

export const Cart: React.FC<CartProps> = ({ isOpen, onClose, items, onUpdateQuantity, onRemoveItem }) => {
  const [promoCode, setPromoCode] = useState('');
  const [discount, setDiscount] = useState(0);

  const subtotal = items.reduce((sum, item) => {
    const price = item.salePrice || item.price;
    return sum + price * item.quantity;
  }, 0);

  const applyPromo = () => {
    if (promoCode.toUpperCase() === 'GUNDAM10') {
      setDiscount(0.1);
      alert("Code GUNDAM10 applied! 10% Off.");
    } else if (promoCode.toUpperCase() === 'GUNPLA20') {
      setDiscount(0.2);
      alert("Code GUNPLA20 applied! 20% Off.");
    } else {
      alert("Invalid code.");
      setDiscount(0);
    }
  };

  const discountAmount = subtotal * discount;
  const total = subtotal - discountAmount;

  return (
    <div className={`fixed inset-0 z-[70] overflow-hidden ${isOpen ? 'pointer-events-auto' : 'pointer-events-none'}`}>
      <div className="absolute inset-0 overflow-hidden">
        <div 
          className={`absolute inset-0 bg-slate-900/80 transition-opacity duration-500 ${isOpen ? 'opacity-100' : 'opacity-0'}`} 
          onClick={onClose}
        />

        <div className={`fixed inset-y-0 right-0 pl-10 max-w-full flex transform transition-transform duration-500 sm:duration-700 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
          <div className="w-screen max-w-md">
            <div className="h-full flex flex-col bg-slate-900 border-l border-slate-700 shadow-2xl">
              
              <div className="flex-1 py-6 overflow-y-auto px-4 sm:px-6">
                <div className="flex items-start justify-between border-b border-slate-700 pb-4">
                  <h2 className="text-lg font-medium text-white font-display uppercase tracking-wider">Shopping Cart</h2>
                  <div className="ml-3 h-7 flex items-center">
                    <button onClick={onClose} className="bg-slate-800 rounded-md text-slate-400 hover:text-white p-1">
                      <X className="h-6 w-6" />
                    </button>
                  </div>
                </div>

                <div className="mt-8">
                  <div className="flow-root">
                    {items.length === 0 ? (
                      <div className="text-center py-12">
                        <ShoppingBag className="mx-auto h-12 w-12 text-slate-600 mb-4" />
                        <p className="text-slate-400">Your cart is empty.</p>
                      </div>
                    ) : (
                      <ul className="-my-6 divide-y divide-slate-700">
                        {items.map((item) => (
                          <li key={item.id} className="py-6 flex">
                            <div className="flex-shrink-0 w-24 h-24 border border-slate-700 rounded-md overflow-hidden bg-slate-800">
                              <img src={item.image} alt={item.name} className="w-full h-full object-center object-cover" />
                            </div>

                            <div className="ml-4 flex-1 flex flex-col">
                              <div>
                                <div className="flex justify-between text-base font-medium text-white">
                                  <h3>{item.name}</h3>
                                  <p className="ml-4">${((item.salePrice || item.price) * item.quantity).toFixed(2)}</p>
                                </div>
                                <p className="mt-1 text-sm text-slate-400">{item.grade} - {item.series}</p>
                              </div>
                              <div className="flex-1 flex items-end justify-between text-sm">
                                <div className="flex items-center border border-slate-600 rounded bg-slate-800">
                                   <button 
                                    onClick={() => onUpdateQuantity(item.id, -1)}
                                    className="px-2 py-1 text-slate-400 hover:text-white"
                                    disabled={item.quantity <= 1}
                                  >-</button>
                                  <span className="px-2 text-white">{item.quantity}</span>
                                  <button 
                                    onClick={() => onUpdateQuantity(item.id, 1)}
                                    className="px-2 py-1 text-slate-400 hover:text-white"
                                  >+</button>
                                </div>

                                <button 
                                  type="button" 
                                  onClick={() => onRemoveItem(item.id)}
                                  className="font-medium text-gundam-red hover:text-red-400 flex items-center"
                                >
                                  <Trash2 className="h-4 w-4 mr-1" /> Remove
                                </button>
                              </div>
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>
              </div>

              {items.length > 0 && (
                <div className="border-t border-slate-700 py-6 px-4 sm:px-6 bg-slate-800/50">
                  
                  <div className="flex gap-2 mb-4">
                    <div className="relative flex-grow">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Tag className="h-4 w-4 text-slate-400" />
                        </div>
                        <input
                            type="text"
                            placeholder="Promo Code"
                            value={promoCode}
                            onChange={(e) => setPromoCode(e.target.value)}
                            className="block w-full pl-10 pr-3 py-2 border border-slate-600 rounded-md leading-5 bg-slate-900 text-slate-300 placeholder-slate-500 focus:outline-none focus:border-gundam-blue focus:ring-1 focus:ring-gundam-blue sm:text-sm"
                        />
                    </div>
                    <button 
                        onClick={applyPromo}
                        className="px-4 py-2 bg-slate-700 text-white rounded hover:bg-slate-600 text-sm font-medium"
                    >
                        Apply
                    </button>
                  </div>

                  <div className="flex justify-between text-base font-medium text-slate-300 mb-2">
                    <p>Subtotal</p>
                    <p>${subtotal.toFixed(2)}</p>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-base font-medium text-gundam-yellow mb-2">
                        <p>Discount</p>
                        <p>-${discountAmount.toFixed(2)}</p>
                    </div>
                  )}
                  <div className="flex justify-between text-xl font-bold text-white mb-6">
                    <p>Total</p>
                    <p>${total.toFixed(2)}</p>
                  </div>
                  <button
                    onClick={() => {
                        alert("Proceeding to checkout simulation...");
                    }}
                    className="w-full flex justify-center items-center px-6 py-3 border border-transparent rounded-sm shadow-sm text-base font-medium text-white bg-gundam-blue hover:bg-blue-700 uppercase tracking-wider"
                  >
                    Checkout
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};